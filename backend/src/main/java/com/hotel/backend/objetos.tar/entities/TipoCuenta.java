package com.hotel.backend.entities;


public enum TipoCuenta {
    ACTIVO, PASIVO, PATRIMONIO, INGRESO, EGRESO
}
