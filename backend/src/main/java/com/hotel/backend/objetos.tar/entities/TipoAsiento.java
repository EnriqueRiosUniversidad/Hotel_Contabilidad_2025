package com.hotel.backend.entities;

enum TipoAsiento {
    AJUSTE, REGULAR, CIERRE
}
