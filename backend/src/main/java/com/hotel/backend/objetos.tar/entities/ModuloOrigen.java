package com.hotel.backend.entities;

enum ModuloOrigen {
    VENTAS, INVENTARIO, FACTURACION, RRHH, OTRO
}
