package com.hotel.backend.entities;


enum EstadoAsiento {
    PENDIENTE, CONFIRMADO, ELIMINADO
}

