package com.hotel.backend.entities;


public enum SubtipoCuenta {
    CIRCULANTE,
    NO_CIRCULANTE,
    NO_CLASIFICADO
}

