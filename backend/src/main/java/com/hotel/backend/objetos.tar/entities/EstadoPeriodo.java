package com.hotel.backend.entities;

public enum EstadoPeriodo {
    EDITABLE, INICIADO, FINALIZADO;
}
