package com.hotel.backend.entities;

enum EstadoAsientoProv {
    BORRADOR, CONFIRMADO
}
